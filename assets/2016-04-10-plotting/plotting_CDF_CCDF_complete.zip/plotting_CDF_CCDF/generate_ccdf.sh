#!/bin/bash

INFILE=$1
OUTFILE=$2

TOTAL=`awk -F " " 'BEGIN {x=0;} {x+=$2;} END {print x;}' $INFILE`;
awk -v total="$TOTAL" -F " " 'BEGIN {sum=0;} {print $1" "(total-sum); sum=sum+$2;}' $INFILE > $OUTFILE;
